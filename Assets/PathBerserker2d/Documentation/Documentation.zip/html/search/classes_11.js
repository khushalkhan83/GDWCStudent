var searchData=
[
  ['updatenotificationwindow_255',['UpdateNotificationWindow',['../classAssets_1_1PathBerserker2d_1_1Scripts_1_1PathBerserker2d_1_1Upgrade_1_1UpdateNotificationWindow.html',1,'Assets::PathBerserker2d::Scripts::PathBerserker2d::Upgrade']]]
];
