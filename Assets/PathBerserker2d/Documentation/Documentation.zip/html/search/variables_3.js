var searchData=
[
  ['enableagentrotation_314',['enableAgentRotation',['../classPathBerserker2d_1_1TransformBasedMovement.html#a91f965d1b0d21aa925cbbf8cfe93a3aa',1,'PathBerserker2d::TransformBasedMovement']]],
  ['enabledfeatures_315',['enabledFeatures',['../classPathBerserker2d_1_1TransformBasedMovement.html#a47dd774ed7f6229f5177a1d320e813b2',1,'PathBerserker2d::TransformBasedMovement']]]
];
