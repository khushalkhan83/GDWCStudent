var searchData=
[
  ['updatemapping_304',['UpdateMapping',['../classPathBerserker2d_1_1NavLink.html#aba325e7024fc36525a1747879b4efcc1',1,'PathBerserker2d.NavLink.UpdateMapping()'],['../classPathBerserker2d_1_1NavLinkCluster.html#a8251212259d07937a30694e0719c578b',1,'PathBerserker2d.NavLinkCluster.UpdateMapping()']]],
  ['updatemappings_305',['UpdateMappings',['../classPathBerserker2d_1_1NavAreaMarker.html#a87ad4344c4e1ed2400c9a380465d8ea6',1,'PathBerserker2d::NavAreaMarker']]],
  ['updatepath_306',['UpdatePath',['../classPathBerserker2d_1_1NavAgent.html#a80c96e9d3ebc77ee0b4a4c715fe99f16',1,'PathBerserker2d.NavAgent.UpdatePath(params Vector2[] goals)'],['../classPathBerserker2d_1_1NavAgent.html#abae46f8648127dda20e66c040208eac3',1,'PathBerserker2d.NavAgent.UpdatePath(Vector2 goal)']]]
];
