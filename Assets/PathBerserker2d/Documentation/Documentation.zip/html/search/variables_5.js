var searchData=
[
  ['goals_318',['goals',['../classPathBerserker2d_1_1PathRequest.html#aec283c7f7f28442b0812c1e004b29902',1,'PathBerserker2d::PathRequest']]]
];
