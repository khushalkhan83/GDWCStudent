var searchData=
[
  ['maxslopeangle_353',['MaxSlopeAngle',['../classPathBerserker2d_1_1NavSurface.html#ad2fc36146d09c50873c86f09541e3b2f',1,'PathBerserker2d::NavSurface']]],
  ['minsegmentlength_354',['MinSegmentLength',['../classPathBerserker2d_1_1NavSurface.html#a653213a38fd862667a1d9de15527aae4',1,'PathBerserker2d::NavSurface']]]
];
