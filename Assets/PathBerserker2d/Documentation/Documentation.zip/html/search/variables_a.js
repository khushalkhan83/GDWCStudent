var searchData=
[
  ['updateaftertime_327',['updateAfterTime',['../classPathBerserker2d_1_1NavAreaMarker.html#afa7ffe16ee4a0531f2d2dea9949f025b',1,'PathBerserker2d::NavAreaMarker']]],
  ['updateaftertimeofnomovement_328',['updateAfterTimeOfNoMovement',['../classPathBerserker2d_1_1NavAreaMarker.html#a0eeafc076c45687bf4e0532b970212aa',1,'PathBerserker2d::NavAreaMarker']]]
];
