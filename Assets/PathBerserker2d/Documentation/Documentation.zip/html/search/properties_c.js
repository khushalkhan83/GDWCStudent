var searchData=
[
  ['worldvelocity_376',['WorldVelocity',['../interfacePathBerserker2d_1_1IVelocityProvider.html#a78a5d9e931d505c219671e6ae8c686f0',1,'PathBerserker2d::IVelocityProvider']]]
];
