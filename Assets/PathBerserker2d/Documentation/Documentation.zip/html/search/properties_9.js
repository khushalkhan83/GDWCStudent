var searchData=
[
  ['smallestdistanceyoucareabout_370',['SmallestDistanceYouCareAbout',['../classPathBerserker2d_1_1NavSurface.html#af369dc49ccc36cc5d622b3739613deb9',1,'PathBerserker2d::NavSurface']]],
  ['status_371',['Status',['../classPathBerserker2d_1_1PathRequest.html#a1e4daf07c26289fa72d9fcf9e5a2792b',1,'PathBerserker2d::PathRequest']]]
];
