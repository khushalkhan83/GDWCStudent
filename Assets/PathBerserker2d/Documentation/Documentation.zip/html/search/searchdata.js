var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuw",
  1: "abcdefgikmnopqrstuw",
  2: "ap",
  3: "abcdefghimprstuw",
  4: "acdefgkrstu",
  5: "s",
  6: "fi",
  7: "cdfhilmnpstuw",
  8: "o",
  9: "cfmnrst"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "properties",
  8: "events",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Properties",
  8: "Events",
  9: "Pages"
};

