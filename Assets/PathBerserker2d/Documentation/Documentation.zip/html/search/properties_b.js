var searchData=
[
  ['usepolygoncollider2dpathsforbaking_375',['UsePolygonCollider2dPathsForBaking',['../classPathBerserker2d_1_1PathBerserker2dSettings.html#a5e7beac84662f6a1f714881647e7c2bf',1,'PathBerserker2d::PathBerserker2dSettings']]]
];
